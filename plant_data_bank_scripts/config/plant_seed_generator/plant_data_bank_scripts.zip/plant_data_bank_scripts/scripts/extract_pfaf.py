from __future__ import annotations
import argparse
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from common import RAW_DIR, clean_text, ensure_dirs, extract_sentences_containing, guess_edible_parts, guess_life_cycle, guess_propagation_methods, guess_use_categories, html_title, http_get, load_plants, plant_filename, source_snapshot, soup_text, write_json
PFAF_SOURCE_NAME='Plants For A Future'

def urls(plant):
    qs=[]
    for k in ['scientific_name','common_name','plant_atom']:
        v=plant.get(k)
        if v and v not in qs: qs.append(v)
    out=[]
    for q in qs:
        out.append(f'https://pfaf.org/user/Plant.aspx?LatinName={quote_plus(q)}')
        out.append(f'https://pfaf.org/user/DatabaseSearhResult.aspx?SearchFor={quote_plus(q)}')
    return out

def tables(html):
    soup=BeautifulSoup(html,'html.parser'); rows=[]
    for tr in soup.find_all('tr'):
        cells=[clean_text(td.get_text(' ')) for td in tr.find_all(['td','th'])]
        cells=[c for c in cells if c]
        if len(cells)>=2: rows.append({'key':cells[0], 'value':' | '.join(cells[1:])})
    return rows[:100]

def parse(html, url):
    text=soup_text(html)
    return {'title': html_title(html), 'page_text': text[:30000], 'tables': tables(html), 'guessed_fields': {
        'life_cycle': guess_life_cycle(text), 'edible_parts': guess_edible_parts(text), 'use_categories': guess_use_categories(text), 'propagation_methods': guess_propagation_methods(text),
        'propagation_notes': extract_sentences_containing(text, ['propagat','seed','cutting','sow','germin'], 8),
        'cultivation_notes': extract_sentences_containing(text, ['cultivat','grow','soil','sun','shade','water','care'], 8),
        'habitat_notes': extract_sentences_containing(text, ['habitat','range','woodland','grassland','field']),
        'known_hazards': extract_sentences_containing(text, ['known hazards','poison','toxic','caution','warning']),
        'medicinal_notes': extract_sentences_containing(text, ['medicinal','medicine'])}}

def extract_one(plant):
    snapshots=[]; q=plant.get('scientific_name') or plant.get('common_name') or plant.get('plant_atom')
    for u in urls(plant):
        try:
            r=http_get(u, delay_seconds=2.0)
            snapshots.append(source_snapshot(PFAF_SOURCE_NAME, r.url, q, 'ok', r.text, parse(r.text, r.url)))
        except Exception as e:
            snapshots.append(source_snapshot(PFAF_SOURCE_NAME, u, q, f'error: {e}', '', {}))
    return {'plant':plant, 'source':PFAF_SOURCE_NAME, 'snapshots':snapshots}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--plants', required=True); args=ap.parse_args(); ensure_dirs()
    for plant in load_plants(args.plants):
        out=RAW_DIR/'pfaf'/plant_filename(plant); write_json(out, extract_one(plant)); print('[PFAF] wrote', out)
if __name__=='__main__': main()
