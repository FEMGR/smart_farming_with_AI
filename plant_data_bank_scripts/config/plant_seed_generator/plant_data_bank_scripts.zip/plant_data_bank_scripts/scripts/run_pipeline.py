from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(cmd): print('\n>>>',' '.join(cmd)); subprocess.run(cmd,cwd=ROOT,check=True)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--plants', required=True); ap.add_argument('--include-perenual', action='store_true'); args=ap.parse_args(); py=sys.executable
    run([py,'scripts/extract_fpi.py','--plants',args.plants]); run([py,'scripts/extract_pfaf.py','--plants',args.plants]); run([py,'scripts/enrich_gbif.py','--plants',args.plants])
    if args.include_perenual: run([py,'scripts/enrich_perenual.py','--plants',args.plants])
    run([py,'scripts/merge_profiles.py','--plants',args.plants]); run([py,'scripts/build_indexes.py']); run([py,'scripts/validate_data_bank.py']); run([py,'scripts/export_to_prolog.py'])
if __name__=='__main__': main()
