from __future__ import annotations
import argparse, os, time, requests
from dotenv import load_dotenv
from common import RAW_DIR, ensure_dirs, load_plants, plant_filename, source_snapshot, write_json
load_dotenv(); PERENUAL_API_KEY=os.getenv('PERENUAL_API_KEY',''); PERENUAL_BASE_URL=os.getenv('PERENUAL_BASE_URL','https://perenual.com/api/v2')

def search(q):
    if not PERENUAL_API_KEY: return {'error':'missing PERENUAL_API_KEY'}
    r=requests.get(f'{PERENUAL_BASE_URL}/species-list', params={'key':PERENUAL_API_KEY,'q':q}, timeout=25); r.raise_for_status(); return r.json()

def detail(i):
    if not PERENUAL_API_KEY: return {'error':'missing PERENUAL_API_KEY'}
    r=requests.get(f'{PERENUAL_BASE_URL}/species/details/{i}', params={'key':PERENUAL_API_KEY}, timeout=25); r.raise_for_status(); return r.json()

def one(plant, delay):
    q=plant.get('scientific_name') or plant.get('common_name') or plant.get('plant_atom'); snaps=[]
    try:
        time.sleep(delay); s=search(q); snaps.append(source_snapshot('Perenual', f'{PERENUAL_BASE_URL}/species-list', q, 'ok', parsed={'endpoint':'species-list','payload':s}))
        details=[]
        for item in (s.get('data') or [])[:3]:
            sid=item.get('id')
            if sid:
                time.sleep(delay); details.append(detail(sid))
        snaps.append(source_snapshot('Perenual', f'{PERENUAL_BASE_URL}/species/details/{{id}}', q, 'ok', parsed={'endpoint':'species-details','payload':details}))
    except Exception as e: snaps.append(source_snapshot('Perenual', PERENUAL_BASE_URL, q, f'error: {e}', parsed={}))
    return {'plant':plant,'source':'Perenual','snapshots':snaps}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--plants', required=True); ap.add_argument('--delay', type=float, default=6.0); args=ap.parse_args(); ensure_dirs()
    for plant in load_plants(args.plants):
        out=RAW_DIR/'perenual'/plant_filename(plant); write_json(out, one(plant,args.delay)); print('[PERENUAL] wrote', out)
if __name__=='__main__': main()
