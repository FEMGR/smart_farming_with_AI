"""
Patch utility helpers for cleaner source extraction.

These functions are intentionally conservative.
They only extract facts from relevant page sections instead of whole-page text.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup


def clean_text(value: str | None) -> str | None:
    if value is None:
        return None
    value = re.sub(r"\s+", " ", value).strip()
    return value or None


def strip_noise(text: str) -> str:
    noise_patterns = [
        r"Translate this page:.*?Summary",
        r"http[s]?://\S+",
        r"Wildlife\s*-\s*Food\s*\(.*?\):\s*Yes",
        r"Skip to Main Content.*?Search results for:",
    ]

    cleaned = text
    for pattern in noise_patterns:
        cleaned = re.sub(pattern, " ", cleaned, flags=re.IGNORECASE | re.DOTALL)

    return clean_text(cleaned) or ""


def page_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript", "nav", "footer", "header"]):
        tag.decompose()
    return clean_text(soup.get_text(" ")) or ""


def title_text(html: str) -> str | None:
    soup = BeautifulSoup(html, "html.parser")
    title = soup.find("title")
    return clean_text(title.get_text(" ")) if title else None


def is_search_page(text: str, title: str | None = None) -> bool:
    combined = f"{title or ''} {text[:1000]}".lower()
    return (
        "search results for" in combined
        or "you searched for" in combined
        or "database search result" in combined
    )


def source_relevance_score(text: str, plant: dict[str, Any]) -> float:
    """
    Score whether the page likely represents the target plant.
    """
    low = text.lower()
    score = 0.0

    scientific = (plant.get("scientific_name") or "").lower()
    common = (plant.get("common_name") or "").lower()

    if scientific and scientific in low:
        score += 0.60

    if common and common in low:
        score += 0.25

    if "edible uses" in low or "edible parts" in low:
        score += 0.10

    if "propagation" in low or "cultivation details" in low:
        score += 0.05

    return min(score, 1.0)


def section_after_heading(text: str, heading: str, stop_headings: list[str] | None = None, max_chars: int = 2500) -> str | None:
    """
    Extract text after a heading until another likely heading.
    Works on flattened page text.
    """
    stop_headings = stop_headings or [
        "Medicinal Uses", "Other Uses", "Propagation", "Cultivation Details",
        "Known Hazards", "Plant Habitats", "Summary", "References", "Links"
    ]

    pattern = re.compile(re.escape(heading), flags=re.IGNORECASE)
    match = pattern.search(text)
    if not match:
        return None

    start = match.end()
    end = min(len(text), start + max_chars)

    for stop in stop_headings:
        if stop.lower() == heading.lower():
            continue
        stop_match = re.search(re.escape(stop), text[start:end], flags=re.IGNORECASE)
        if stop_match:
            end = start + stop_match.start()
            break

    return clean_text(text[start:end])


def extract_edible_parts_from_section(section: str | None) -> list[str]:
    """
    Only infer edible parts from edible-use section, not the whole page.
    """
    if not section:
        return []

    low = section.lower()
    parts = []

    rules = {
        "leaf": ["leaves", "leaf"],
        "flower": ["flowers", "flower"],
        "seed": ["seeds", "seed"],
        "fruit": ["fruits", "fruit"],
        "root": ["roots", "root"],
        "tuber": ["tubers", "tuber"],
        "rhizome": ["rhizomes", "rhizome"],
        "stem": ["stems", "stem", "shoots", "shoot"],
        "bulb": ["bulbs", "bulb"],
        "pod": ["pods", "pod"],
    }

    for part, needles in rules.items():
        if any(re.search(rf"\b{re.escape(n)}\b", low) for n in needles):
            parts.append(part)

    return sorted(set(parts))


def extract_use_categories_from_sections(edible_section: str | None, medicinal_section: str | None, common_name: str | None = None) -> list[str]:
    text = f"{edible_section or ''} {common_name or ''}".lower()
    medicinal = (medicinal_section or "").lower()

    categories = []

    if any(w in text for w in ["condiment", "flavouring", "flavoring", "tea", "herb", "basil", "sage", "mint", "thyme"]):
        categories.append("culinary_herb")

    if medicinal:
        categories.append("medicinal_plant")

    if any(w in text for w in ["fruit", "fruits", "berry", "berries"]) and "leaf" not in text:
        categories.append("fruit_crop")

    if any(w in text for w in ["root", "tuber", "rhizome", "corm"]) and "rootstock" not in text:
        categories.append("root_tuber_crop")

    if "edible flower" in text or "flowers - raw" in text or "flowers - cooked" in text:
        categories.append("edible_flower")

    return sorted(set(categories))


def extract_propagation_methods_from_section(section: str | None) -> list[str]:
    if not section:
        return []

    low = section.lower()
    methods = []

    rules = {
        "seed": ["seed", "seeds", "sow", "sown"],
        "cutting": ["cutting", "cuttings"],
        "division": ["division", "divide"],
        "layering": ["layering"],
        "grafting": ["graft", "grafting"],
        "bulb": ["bulb", "bulbs"],
        "rhizome": ["rhizome", "rhizomes"],
        "tuber": ["tuber", "tubers"],
    }

    for method, needles in rules.items():
        if any(re.search(rf"\b{re.escape(n)}\b", low) for n in needles):
            methods.append(method)

    return sorted(set(methods))


def strongly_detect_life_cycle(text: str) -> str | None:
    """
    Conservative life-cycle detection.
    Avoids marking plants perennial just because the page mentions generic perennial info.
    """
    low = text.lower()

    if re.search(r"\bis an annual\b|\bannual herb\b|\bgrown as an annual\b", low):
        return "annual"

    if re.search(r"\bis a perennial\b|\bperennial herb\b|\bperennial plant\b", low):
        return "perennial"

    if re.search(r"\bis a biennial\b|\bbiennial plant\b", low):
        return "biennial"

    return None
